import xbmcaddon

MainBase = 'https://mykodirepo20.000webhostapp.com/xxxworld/home.txt'
addon = xbmcaddon.Addon('plugin.video.xxxworld')